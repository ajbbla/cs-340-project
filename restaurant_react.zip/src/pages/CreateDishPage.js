
{/* <div>
    <h1>Add Order</h1>
    <input
        type="text"
        placeholder="Enter orderID here"
        value={name}
        onChange={e => setName(e.target.value)} />
    <input
        type="reps"
        placeholder="Enter dateTime here"
        value={reps}
        onChange={e => setReps(e.target.value)} />
    <input
        type="text"
        placeholder="Enter totalPrice here"
        value={weight}
        onChange={e => setWeight(e.target.value)} />
    <select value={unit} onChange={e => setUnit(e.target.value)}>
        <option value={"kgs"}>kgs</option>
        <option value={"lbs"}>lbs</option>
    </select>
    <input
        type="text"
        placeholder="Enter date here"
        value={date}
        onChange={e => setDate(e.target.value)} />
    <button
        onClick={addExercise}
    >Add</button>
</div> */}

//const [unit, setUnit] = useState('lbs');